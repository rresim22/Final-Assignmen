def get_input(prompt, valid_responses):
    while True:
        response = input(prompt).lower()
        if response in valid_responses:
            return response
        else:
            print("Invalid input. Please enter correct response, Thank you.")

def get_number_of_pizzas():
    while True:
        try:
            number_of_pizzas = int(input("How many pizzas are ordered? "))
            if number_of_pizzas > 0:
                return number_of_pizzas
            else:
                print("Please enter a positive integer!")
        except ValueError:
            print("Please enter a number!")

def calculate_price(number_of_pizzas, is_tuesday, is_app_user, is_delivery_required):
    base_price = number_of_pizzas * 12
    tuesday_discount = 0.5 if is_tuesday else 0
    app_discount = 0.25 if is_app_user else 0
    delivery_cost = 2.5 if is_delivery_required and number_of_pizzas < 5 else 0
    total_price = base_price * (1 - tuesday_discount - app_discount) + delivery_cost
    return round(total_price, 2)

def main():
    number_of_pizzas = get_number_of_pizzas()
    is_tuesday = get_input("Is it Tuesday? ", ["yes", "no"]) == "yes"
    is_delivery_required = get_input("Is delivery required? ", ["yes", "no"]) == "yes"
    is_app_user = get_input("Did the customer use the app? ", ["yes", "no"]) == "yes"
    total_price = calculate_price(number_of_pizzas, is_tuesday, is_app_user, is_delivery_required)
    print(f"Total Price: £{total_price}.")

if __name__ == "__main__":
    main()