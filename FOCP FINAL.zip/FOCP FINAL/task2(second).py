import sys

def parse_entry(entry):
    cat, enter_time, exit_time = entry.strip().split(',')
    return cat, int(enter_time), int(exit_time)

def analyze_log(log_file):
    cat_visits = 0
    other_cats = 0
    total_time_in_house = 0
    visit_lengths = []

    try:
        with open(log_file, 'r') as file:
            for line in file:
                if line.strip() == 'END':
                    break

                cat, enter_time, exit_time = parse_entry(line)

                if cat == 'OURS':
                    cat_visits += 1
                    total_time_in_house += (exit_time - enter_time)
                    visit_lengths.append(exit_time - enter_time)
                elif cat == 'THEIRS':
                    other_cats += 1

        if cat_visits == 0:
            print("No cat visits recorded.")
            return

        avg_visit_length = sum(visit_lengths) / cat_visits
        longest_visit = max(visit_lengths)
        shortest_visit = min(visit_lengths)

        print("\nLog File Analysis\n==================\n")
        print(f"Cat Visits: {cat_visits}")
        print(f"Other Cats: {other_cats}\n")
        print(f"Total Time in House: {total_time_in_house // 60} Hours, {total_time_in_house % 60} Minutes\n")
        print(f"Average Visit Length: {avg_visit_length} Minutes")
        print(f"Longest Visit:        {longest_visit} Minutes")
        print(f"Shortest Visit:       {shortest_visit} Minutes")

    except FileNotFoundError:
        print(f'Cannot open "{log_file}"!')
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: ./cat_shelter.py <log_file>")
        sys.exit(1)

    log_file = sys.argv[1]
    analyze_log(log_file)
